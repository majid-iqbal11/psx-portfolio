# 📈 PSX Portfolio Analyzer v2.2
### Capital Markets Education & Portfolio Intelligence Platform
**Prepared by: Kashan Kazmi | CFA-Aligned | Pakistan Stock Exchange**

---

## 🚀 GitHub Me Kaise Paste Karein — Step by Step

### Step 1 — GitHub Par New Repository Banao
1. **github.com** par jao
2. Green **"New"** button dabao (top left)
3. Repository name likho: `psx-portfolio-analyzer`
4. **Public** select karo
5. **"Create repository"** dabao

### Step 2 — Files Upload Karo
1. Apne naye repo mein **"uploading an existing file"** link dabao
2. Is ZIP ko extract karo — yeh files milegi:
   - `login.html`
   - `index.html`
   - `css/app.css`
   - `js/app.js`
   - `README.md`
3. Saari files/folders GitHub par **drag and drop** karo
4. Neechay **"Commit changes"** dabao

### Step 3 — Live Website Banao (GitHub Pages)
1. Repo mein **Settings** tab dabao
2. Left sidebar mein **"Pages"** dabao
3. **Source:** "Deploy from branch" select karo
4. **Branch:** `main` → `/` (root) → **Save**
5. 2–3 minute wait karo
6. Tumhari live website: `https://TUMHARA_USERNAME.github.io/psx-portfolio-analyzer/login.html`

---

## 🔐 Login Credentials

| Role | User ID | Password |
|------|---------|----------|
| Admin (Kashan) | `kashan` | `PSX@2026` |
| W2 Moderate | `investor1` | `Pass@123` |
| W1 Conservative | `conservative` | `Safe@456` |
| W3 Aggressive | `aggressive` | `Risk@789` |

> Naya account bhi bana sakte ho — Register tab par jao

---

## 📁 File Structure

```
psx-portfolio-analyzer/
│
├── login.html          ← Login + Register page (yahan se shuru hota hai)
├── index.html          ← Main dashboard (10 modules)
│
├── css/
│   └── app.css         ← Professional dark theme styles
│
├── js/
│   └── app.js          ← Saara logic, data, charts
│
└── README.md           ← Yeh file
```

---

## 📋 App Features — 10 Complete Modules

| # | Module | Description |
|---|--------|-------------|
| 1 | 📊 Dashboard | Portfolio value, CAGR, alpha vs KSE-100, dividend calendar, auto-commentary |
| 2 | 💼 Holdings | 12 stocks, Blue Chip/Growth/Cyclical/Penny badges, P/E, Div Yield, Beta |
| 3 | ⇄ Transactions | FIFO cost basis, brokerage + FED auto-calc, CGT slab per holding period |
| 4 | 📉 Benchmarks | KSE-100, KSE-30, KMI-30, BKTI, OGTI traffic-light signals + chart |
| 5 | 🏦 Copy Portfolio | MUFAP fund monitor — IR, CAGR, Alpha, 1Y/2Y returns + ETF comparison |
| 6 | 🧮 Valuation | EPS, DPS, Payout%, NBV, P/E, P/B, Beta — 12 PSX stocks |
| 7 | 🧾 Tax & CGT | FY27 CGT calc, WHT summary, FBR IRIS filing 5-step guide |
| 8 | 🛡 Risk Profile | W1/W2/W3 questionnaire Part A + B (income assessment) |
| 9 | 🎓 Education Hub | 7 stock categories, 4 context triggers, 3 proficiency levels |
| 10 | 🔀 Scenarios | What-If builder, underperformer replacement, 2-year projections |

---

## ⚠️ Disclaimer
For educational purposes only. App Group 4 members only. Not for public circulation. Does not execute trades. Not SECP-licensed advice. All investment decisions remain with the user.
