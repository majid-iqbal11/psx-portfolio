/* ================================================
   PSX PORTFOLIO ANALYZER — COMPLETE APP LOGIC
   Version 2.2 | Kashan Kazmi | App Group 4
   ================================================ */

'use strict';

/* ── Auth guard ── */
const CURRENT_USER = JSON.parse(sessionStorage.getItem('psxUser') || 'null');
if (!CURRENT_USER && window.location.pathname.indexOf('login') === -1) {
  window.location.href = 'login.html';
}

/* ════════════════════════════════════════
   DATA — ALL PSX PORTFOLIO DATA
   ════════════════════════════════════════ */

const HOLDINGS = [
  { ticker:'MCB',    name:'MCB Bank',              type:'blue-chip', qty:500,  cost:380,  cmp:404,  pe:8.3,  pb:2.1,  dps:36.00, beta:0.87, yld:8.9,  bucket:'high-yield'  },
  { ticker:'FFC',    name:'Fauji Fertilizer',       type:'blue-chip', qty:500,  cost:510,  cmp:556,  pe:10.2, pb:4.0,  dps:34.86, beta:0.98, yld:6.3,  bucket:'high-yield'  },
  { ticker:'OGDC',   name:'OGDC',                   type:'blue-chip', qty:500,  cost:295,  cmp:312,  pe:5.4,  pb:1.2,  dps:15.00, beta:0.36, yld:4.8,  bucket:'high-yield'  },
  { ticker:'MEBL',   name:'Meezan Bank',             type:'blue-chip', qty:400,  cost:470,  cmp:500,  pe:9.9,  pb:2.8,  dps:28.00, beta:0.85, yld:5.6,  bucket:'high-yield'  },
  { ticker:'UBL',    name:'United Bank',             type:'blue-chip', qty:300,  cost:390,  cmp:420,  pe:6.4,  pb:1.2,  dps:36.00, beta:0.92, yld:8.6,  bucket:'high-yield'  },
  { ticker:'PPL',    name:'Pakistan Petroleum',      type:'blue-chip', qty:600,  cost:156,  cmp:170,  pe:5.2,  pb:0.87, dps:7.50,  beta:0.81, yld:4.4,  bucket:'high-yield'  },
  { ticker:'FCCL',   name:'Fauji Cement',            type:'growth',    qty:1000, cost:52,   cmp:58,   pe:6.8,  pb:4.1,  dps:2.00,  beta:1.45, yld:3.4,  bucket:'high-growth' },
  { ticker:'PSO',    name:'Pakistan State Oil',      type:'cyclical',  qty:300,  cost:340,  cmp:362,  pe:7.2,  pb:1.6,  dps:20.00, beta:1.15, yld:5.5,  bucket:'high-growth' },
  { ticker:'BOP',    name:'Bank of Punjab',          type:'cyclical',  qty:2000, cost:34,   cmp:37,   pe:8.8,  pb:3.7,  dps:4.00,  beta:1.55, yld:10.8, bucket:'high-growth' },
  { ticker:'AKBL',   name:'Askari Bank',             type:'cyclical',  qty:1000, cost:91,   cmp:100,  pe:8.3,  pb:4.0,  dps:8.00,  beta:1.30, yld:8.0,  bucket:'high-growth' },
  { ticker:'LCI',    name:'Lucky Cement',            type:'blue-chip', qty:200,  cost:215,  cmp:237,  pe:5.6,  pb:2.7,  dps:28.00, beta:1.08, yld:11.8, bucket:'high-growth' },
  { ticker:'CNERGY', name:'Cnergyico PK',            type:'penny',     qty:5000, cost:9.7,  cmp:8.0,  pe:10.5, pb:1.7,  dps:0,     beta:1.85, yld:0,    bucket:'trending'    },
];

const VALUATION = [
  { ticker:'MCB',    eps:48.62, fy:'FY2024-Aud', dps:36.00, payout:74,  nbv:197,  price:404,   pe:8.3,  pb:2.1,  beta:0.87, yld:8.9,  freq:'4x/yr', type:'blue-chip'  },
  { ticker:'FFC',    eps:45.89, fy:'FY2024-Aud', dps:34.86, payout:76,  nbv:138,  price:556,   pe:10.2, pb:4.0,  beta:0.98, yld:6.3,  freq:'4x/yr', type:'blue-chip'  },
  { ticker:'UBL',    eps:66.0,  fy:'FY2024-Aud', dps:36.00, payout:55,  nbv:350,  price:420,   pe:6.4,  pb:1.2,  beta:0.92, yld:8.6,  freq:'4x/yr', type:'blue-chip'  },
  { ticker:'MEBL',   eps:50.47, fy:'FY2025-Aud', dps:28.00, payout:55,  nbv:180,  price:500,   pe:9.9,  pb:2.8,  beta:0.85, yld:5.6,  freq:'4x/yr', type:'blue-chip'  },
  { ticker:'OGDC',   eps:38.94, fy:'FY2025-Aud', dps:15.00, payout:38,  nbv:252,  price:312,   pe:5.4,  pb:1.2,  beta:0.36, yld:4.8,  freq:'4x/yr', type:'blue-chip'  },
  { ticker:'PPL',    eps:32.97, fy:'TTM-Unaud',  dps:7.50,  payout:23,  nbv:196,  price:170,   pe:5.2,  pb:0.87, beta:0.81, yld:4.4,  freq:'Irr.',  type:'blue-chip'  },
  { ticker:'MARI',   eps:120.0, fy:'FY2025-Aud', dps:65.00, payout:54,  nbv:280,  price:636,   pe:5.3,  pb:2.3,  beta:1.05, yld:10.2, freq:'2x/yr', type:'growth'     },
  { ticker:'SAZEW',  eps:320.0, fy:'FY2025-Aud', dps:215.0, payout:67,  nbv:530,  price:2160,  pe:6.8,  pb:4.1,  beta:0.61, yld:10.0, freq:'4x/yr', type:'blue-chip'  },
  { ticker:'ATLH',   eps:285.0, fy:'FY2025-Aud', dps:245.0, payout:86,  nbv:640,  price:1750,  pe:6.1,  pb:2.7,  beta:0.68, yld:14.0, freq:'2x/yr', type:'blue-chip'  },
  { ticker:'MTL',    eps:120.0, fy:'FY2025-Aud', dps:80.00, payout:67,  nbv:310,  price:578,   pe:4.8,  pb:1.9,  beta:0.65, yld:13.8, freq:'2x/yr', type:'blue-chip'  },
  { ticker:'HINOON', eps:195.0, fy:'FY2025-Aud', dps:120.0, payout:62,  nbv:420,  price:990,   pe:5.1,  pb:2.4,  beta:0.55, yld:12.1, freq:'2x/yr', type:'blue-chip'  },
  { ticker:'AKBL',   eps:12.0,  fy:'FY2025-Aud', dps:8.00,  payout:67,  nbv:25,   price:100,   pe:8.3,  pb:4.0,  beta:1.30, yld:8.0,  freq:'Annual',type:'cyclical'   },
  { ticker:'FCCL',   eps:8.5,   fy:'FY2025-Aud', dps:2.00,  payout:24,  nbv:14,   price:58,    pe:6.8,  pb:4.1,  beta:1.45, yld:3.4,  freq:'Annual',type:'growth'     },
  { ticker:'LCI',    eps:42.0,  fy:'FY2025-Aud', dps:28.00, payout:67,  nbv:88,   price:237,   pe:5.6,  pb:2.7,  beta:1.08, yld:11.8, freq:'2x/yr', type:'blue-chip'  },
  { ticker:'PSO',    eps:50.0,  fy:'FY2025-Aud', dps:20.00, payout:40,  nbv:225,  price:362,   pe:7.2,  pb:1.6,  beta:1.15, yld:5.5,  freq:'2x/yr', type:'cyclical'   },
  { ticker:'BOP',    eps:4.2,   fy:'FY2025-Aud', dps:4.00,  payout:95,  nbv:10,   price:37,    pe:8.8,  pb:3.7,  beta:1.55, yld:10.8, freq:'Annual',type:'cyclical'   },
  { ticker:'CNERGY', eps:0.8,   fy:'FY2025-Aud', dps:0,     payout:0,   nbv:5,    price:8,     pe:10.5, pb:1.7,  beta:1.85, yld:0,    freq:'None',  type:'penny'      },
  { ticker:'LOTCHEM',eps:4.2,   fy:'FY2025-Aud', dps:8.00,  payout:190, nbv:18,   price:29,    pe:6.9,  pb:1.6,  beta:1.35, yld:27.6, freq:'Annual',type:'turnaround' },
  { ticker:'HASCOL', eps:-2.1,  fy:'FY2025',     dps:0,     payout:0,   nbv:4,    price:22,    pe:null, pb:5.5,  beta:2.10, yld:0,    freq:'None',  type:'junk'       },
];

const FUNDS = [
  { name:'Al Meezan Mutual Fund',     amc:'Al Meezan', y1:28.3, y2:54.3, cagr:23.1, sharpe:1.42, alpha:5.2, ir:0.62, type:'Shariah'     },
  { name:'NBP Stock Fund',            amc:'NBP Funds', y1:26.7, y2:51.8, cagr:21.8, sharpe:1.38, alpha:3.1, ir:0.48, type:'Conv. Equity' },
  { name:'UBL Stock Advantage Fund',  amc:'UBL FM',    y1:25.4, y2:49.6, cagr:21.1, sharpe:1.31, alpha:2.4, ir:0.41, type:'Conv. Equity' },
  { name:'Atlas Stock Market Fund',   amc:'Atlas AM',  y1:25.1, y2:48.9, cagr:20.8, sharpe:1.29, alpha:2.2, ir:0.39, type:'Conv. Equity' },
  { name:'MCB Pakistan Stock Market', amc:'MCB-IM',    y1:23.8, y2:46.2, cagr:19.8, sharpe:1.22, alpha:1.5, ir:0.31, type:'Conv. Equity' },
  { name:'UBL Islamic Equity Fund',   amc:'UBL FM',    y1:23.1, y2:45.8, cagr:19.5, sharpe:1.20, alpha:1.2, ir:0.28, type:'Shariah'     },
  { name:'HBL Multi-Asset Fund',      amc:'HBL AM',    y1:22.4, y2:44.1, cagr:18.9, sharpe:1.18, alpha:0.9, ir:0.24, type:'Conv. Equity' },
];

let TX_LEDGER = [
  { date:'2026-01-01', type:'BUY',  ticker:'MCB',    qty:500,  price:380, brok:285.0, fed:45.6,  adj:190571, days:173 },
  { date:'2026-01-01', type:'BUY',  ticker:'FFC',    qty:500,  price:510, brok:382.5, fed:61.2,  adj:255764, days:173 },
  { date:'2026-03-15', type:'BUY',  ticker:'FCCL',   qty:1000, price:52,  brok:78.0,  fed:12.5,  adj:52091,  days:97  },
  { date:'2026-02-10', type:'SELL', ticker:'HASCOL', qty:2000, price:25,  brok:100.0, fed:16.0,  adj:49900,  days:null},
];

const TYPE_MAP = {
  'blue-chip':  ['b-teal', '⭐ Blue Chip'],
  'growth':     ['b-blue', '🚀 Growth'],
  'cyclical':   ['b-gold', '🔄 Cyclical'],
  'penny':      ['b-red',  '⚡ Penny'],
  'turnaround': ['b-gold', '🔀 Turnaround'],
  'junk':       ['b-red',  '⚠ Junk'],
};

/* ════════════════════════════════════════
   NAVIGATION
   ════════════════════════════════════════ */
const SECTION_TITLES = {
  dashboard:'Dashboard', holdings:'Holdings', transactions:'Transactions',
  benchmark:'Benchmarks', funds:'Copy Portfolio', valuation:'Valuation Intelligence',
  tax:'Tax & CGT', risk:'Risk Profile', education:'Education Hub', scenario:'Scenario Builder'
};

let _sideCollapsed = false;
let _chartMap = {};

window.showSection = function(id, el) {
  document.querySelectorAll('[id^="s-"]').forEach(s => s.classList.add('section-hidden'));
  const sec = document.getElementById('s-' + id);
  if (sec) sec.classList.remove('section-hidden');
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  if (el) el.classList.add('active');
  const titleEl = document.getElementById('page-title');
  if (titleEl) titleEl.textContent = SECTION_TITLES[id] || id;
  if (id === 'benchmark') setTimeout(drawBenchChart, 120);
  if (id === 'tax')       setTimeout(drawTaxChart, 120);
};

window.toggleSidebar = function() {
  _sideCollapsed = !_sideCollapsed;
  const sb = document.querySelector('.sidebar');
  const btn = document.getElementById('sb-collapse');
  if (sb)  sb.classList.toggle('collapsed', _sideCollapsed);
  if (btn) btn.textContent = _sideCollapsed ? '›' : '‹';
};

window.setPeriod = function(el) {
  el.closest('.period-row').querySelectorAll('.ptab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
};

window.selectRisk = function(el) {
  document.querySelectorAll('.risk-card').forEach(c => c.classList.remove('sel'));
  el.classList.add('sel');
};

window.selectQ = function(el) {
  el.parentElement.querySelectorAll('.ro').forEach(o => o.classList.remove('sel'));
  el.classList.add('sel');
};

window.logout = function() {
  if (confirm('PSX Portfolio Analyzer se sign out karein?')) {
    sessionStorage.removeItem('psxUser');
    window.location.href = 'login.html';
  }
};

/* ════════════════════════════════════════
   USER UI INIT
   ════════════════════════════════════════ */
function initUser() {
  if (!CURRENT_USER) return;
  const firstName = CURRENT_USER.name.split(' ')[0];
  const initials  = CURRENT_USER.name.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase();
  _set('u-name',    firstName);
  _set('u-risk',    CURRENT_USER.risk + ' Profile');
  _set('u-initials',initials);
}
function _set(id, val) { const el=document.getElementById(id); if(el) el.textContent=val; }

/* ════════════════════════════════════════
   RENDER HOLDINGS
   ════════════════════════════════════════ */
function renderHoldings() {
  const tbody = document.getElementById('hold-body');
  if (!tbody) return;
  let totalVal = 0;
  tbody.innerHTML = HOLDINGS.map(h => {
    const g   = ((h.cmp - h.cost) / h.cost * 100).toFixed(1);
    const mkt = h.qty * h.cmp;
    totalVal += mkt;
    const [bc, bt] = TYPE_MAP[h.type] || ['b-gray','—'];
    const gc = parseFloat(g) >= 0 ? 'pos' : 'neg';
    const sign = parseFloat(g) >= 0 ? '+' : '';
    return `<tr onclick="stockDetail('${h.ticker}')">
      <td class="tc">${h.ticker}</td>
      <td>${h.name}</td>
      <td><span class="badge ${bc}">${bt}</span></td>
      <td class="tr">${h.qty.toLocaleString()}</td>
      <td class="tr">₨ ${h.cost.toFixed(0)}</td>
      <td class="tr">₨ ${h.cmp.toFixed(0)}</td>
      <td class="tr ${gc}">${sign}${g}%</td>
      <td class="tr">₨ ${mkt.toLocaleString()}</td>
      <td class="tr">${h.pe}×</td>
      <td class="tr ${h.yld >= 8 ? 'pos' : ''}">${h.yld}%</td>
      <td class="tr ${h.beta > 1.5 ? 'neg' : h.beta < 0.8 ? 'pos' : ''}">${h.beta}</td>
    </tr>`;
  }).join('');
}

window.stockDetail = function(ticker) {
  const h = HOLDINGS.find(x => x.ticker === ticker);
  const v = VALUATION.find(x => x.ticker === ticker);
  if (!h && !v) return;
  const d = h || v;
  alert(`📊 ${ticker} — Full Detail\n\n` +
    `Company: ${h ? h.name : ticker}\n` +
    `P/E Ratio: ${d.pe}×\n` +
    `P/B Ratio: ${d.pb}×\n` +
    `Beta: ${d.beta}\n` +
    `Dividend Yield: ${d.yld}%\n` +
    `DPS (₨): ${d.dps || 'NIL'}\n\n` +
    `Live build mein yahan milega:\n` +
    `• 5-year price chart\n` +
    `• EPS trend (5 years)\n` +
    `• Dividend history\n` +
    `• Peer comparison\n` +
    `• FBR CGT impact calculator`);
};

/* ════════════════════════════════════════
   RENDER VALUATION
   ════════════════════════════════════════ */
function renderValuation() {
  const tbody = document.getElementById('val-body');
  if (!tbody) return;
  const aud = `<span class="badge b-teal" style="font-size:9px;padding:1px 5px">AUD</span>`;
  const una = `<span class="badge b-gold" style="font-size:9px;padding:1px 5px">UNA</span>`;
  tbody.innerHTML = VALUATION.map(v => {
    const isLoss   = v.eps < 0;
    const isUnaud  = v.fy.includes('Unaud') || v.fy.includes('TTM');
    const pWarn    = v.payout > 100;
    const pClass   = pWarn ? 'neg' : v.payout > 80 ? 'warn' : '';
    const [bc, bt] = TYPE_MAP[v.type] || ['b-gray','—'];
    const bClass   = v.beta > 1.5 ? 'neg' : v.beta < 0.8 ? 'pos' : '';
    const yClass   = v.yld >= 10 ? 'pos' : v.yld === 0 ? 'neg' : '';
    return `<tr onclick="stockDetail('${v.ticker}')">
      <td class="tc">${v.ticker}</td>
      <td class="tr">${isLoss ? '<span class="neg">LOSS</span>' : v.eps.toFixed(2)+' '+(isUnaud?una:aud)}</td>
      <td class="tr">${v.dps > 0 ? v.dps.toFixed(2) : 'NIL'}</td>
      <td class="tr ${pClass}">${v.payout > 0 ? v.payout+'%' : 'N/A'}${pWarn ? ' ⚠' : ''}</td>
      <td class="tr">₨ ${v.nbv}</td>
      <td class="tr" style="font-weight:600">₨ ${v.price.toLocaleString()}</td>
      <td class="tr">${v.pe ? v.pe+'×' : 'N/A'}</td>
      <td class="tr">${v.pb}×</td>
      <td class="tr ${bClass}">${v.beta}</td>
      <td class="tr ${yClass}">${v.yld > 0 ? v.yld+'%' : '0%'}</td>
      <td>${v.freq}</td>
      <td><span class="badge ${bc}" style="font-size:10px">${bt}</span></td>
    </tr>`;
  }).join('');
}

/* ════════════════════════════════════════
   RENDER FUNDS
   ════════════════════════════════════════ */
function renderFunds() {
  const tbody = document.getElementById('fund-body');
  if (!tbody) return;
  tbody.innerHTML = FUNDS.map(f => {
    const irPct = Math.min(100, Math.round(f.ir * 100));
    const tc    = f.type === 'Shariah' ? 'b-teal' : 'b-blue';
    const irCol = f.ir >= 0.5 ? 'var(--teal)' : f.ir >= 0.3 ? 'var(--gold)' : 'var(--red)';
    return `<tr>
      <td style="font-weight:600;color:var(--text)">${f.name}</td>
      <td style="color:var(--muted)">${f.amc}</td>
      <td class="tr pos">${f.y1}%</td>
      <td class="tr">${f.y2}%</td>
      <td class="tr" style="font-weight:700">${f.cagr}%</td>
      <td class="tr">${f.sharpe}</td>
      <td class="tr pos">+${f.alpha}%</td>
      <td style="min-width:80px">
        <div style="text-align:right;font-weight:700;font-size:12px;color:${irCol}">${f.ir}</div>
        <div class="ir-bar" style="width:70px"><div class="ir-fill" style="width:${irPct}%;background:${irCol}"></div></div>
      </td>
      <td><span class="badge ${tc}" style="font-size:10px">${f.type}</span></td>
      <td><button class="btn btn-ghost btn-sm" onclick="copyFund('${f.name}')">Copy ↗</button></td>
    </tr>`;
  }).join('');
}

window.copyFund = function(name) {
  alert(`📋 Copy Portfolio: ${name}\n\n` +
    `MUFAP monthly disclosure se top-10 holdings load hongi.\n\n` +
    `Copy Mode options:\n` +
    `① Exact Weights — fund ka exact % replicate karo\n` +
    `② Tickers Only — same stocks, apni marzi ke weights\n` +
    `③ Smart Copy — W2 risk model ke liye auto-adjusted\n\n` +
    `Overlap Analysis:\n` +
    `🟢 GREEN = already hold\n` +
    `🟡 AMBER = partially own\n` +
    `⬜ GREY = new idea\n\n` +
    `Data source: mufap.com.pk (free, monthly, 10th of each month)`);
};

/* ════════════════════════════════════════
   TRANSACTIONS
   ════════════════════════════════════════ */
let _txType = 'BUY';

window.setTxType = function(t, el) {
  _txType = t;
  document.querySelectorAll('#btn-buy,#btn-sell').forEach(b => b.classList.remove('sel'));
  el.classList.add('sel');
};

window.calcPreview = function() {
  const qty   = parseFloat(document.getElementById('tx-qty')?.value)   || 0;
  const price = parseFloat(document.getElementById('tx-price')?.value) || 0;
  const brok  = parseFloat(document.getElementById('tx-brok')?.value)  || (qty * price * 0.0015);
  const fed   = brok * 0.16;
  const gross = qty * price;
  const adj   = gross + brok + fed;
  _set('p-gross', gross > 0 ? '₨ ' + Math.round(gross).toLocaleString() : '—');
  _set('p-brok',  gross > 0 ? '₨ ' + (Math.round((brok + fed) * 10) / 10).toLocaleString() : '—');
  _set('p-adj',   gross > 0 ? '₨ ' + Math.round(adj).toLocaleString() : '—');
};

window.addTransaction = function() {
  const ticker = (document.getElementById('tx-ticker')?.value || 'MCB').toUpperCase();
  const date   = document.getElementById('tx-date')?.value  || '2026-06-21';
  const qty    = parseInt(document.getElementById('tx-qty')?.value)   || 100;
  const price  = parseFloat(document.getElementById('tx-price')?.value) || 400;
  const brok   = parseFloat(document.getElementById('tx-brok')?.value) || (qty * price * 0.0015);
  const fed    = brok * 0.16;
  const adj    = Math.round(qty * price + brok + fed);
  const today  = new Date('2026-06-21');
  const tDate  = new Date(date);
  const days   = _txType === 'BUY' ? Math.round((today - tDate) / 86400000) : null;

  TX_LEDGER.unshift({ date, type: _txType, ticker, qty, price, brok: Math.round(brok * 10) / 10, fed: Math.round(fed * 10) / 10, adj, days });
  renderTransactions();

  // Clear inputs
  ['tx-ticker','tx-qty','tx-price','tx-brok'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  calcPreview();
};

function renderTransactions() {
  const tbody = document.getElementById('tx-body');
  if (!tbody) return;
  tbody.innerHTML = TX_LEDGER.map(t => {
    const d    = new Date(t.date).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'2-digit' });
    const tCol = t.type === 'BUY' ? 'pos' : 'neg';
    let cgt = '—', cgtC = '';
    if (t.days !== null && t.days !== undefined) {
      if      (t.days < 365) { cgt = '12.5%'; cgtC = 'neg'; }
      else if (t.days < 730) { cgt = '10.0%'; cgtC = 'warn'; }
      else                   { cgt = '7.5%';  cgtC = 'pos'; }
    } else {
      cgt = 'Realised'; cgtC = 'pos';
    }
    const dBadge = t.days !== null && t.days !== undefined
      ? `<span class="badge ${t.days >= 365 ? 'b-teal' : 'b-gold'}">${t.days}d</span>`
      : `<span class="badge b-gray">Settled</span>`;
    return `<tr>
      <td>${d}</td>
      <td class="${tCol}" style="font-weight:700">${t.type}</td>
      <td class="tc">${t.ticker}</td>
      <td class="tr">${t.qty.toLocaleString()}</td>
      <td class="tr">₨ ${t.price.toFixed(0)}</td>
      <td class="tr" style="color:var(--muted)">₨${t.brok.toFixed(0)} + ₨${t.fed.toFixed(0)}</td>
      <td class="tr" style="font-weight:600">₨ ${t.adj.toLocaleString()}</td>
      <td>${dBadge}</td>
      <td class="tr ${cgtC}">${cgt}</td>
    </tr>`;
  }).join('');
}

/* ════════════════════════════════════════
   SCENARIO BUILDER
   ════════════════════════════════════════ */
window.runScenario = function() {
  const ticker   = (document.getElementById('sc-ticker')?.value || 'HINOON').toUpperCase();
  const weight   = parseInt(document.getElementById('sc-weight')?.value) || 5;
  const bDelta   = ((Math.random() * 0.14) - 0.07).toFixed(2);
  const yDelta   = (Math.random() * 1.8 + 0.4).toFixed(1);
  const newBeta  = (0.93 + parseFloat(bDelta)).toFixed(2);
  const newYld   = (3.8  + parseFloat(yDelta)).toFixed(1);
  const bSign    = parseFloat(bDelta) > 0 ? '+' : '';
  const bClass   = parseFloat(bDelta) > 0 ? 'neg' : 'pos';
  const w2ok     = parseFloat(newBeta) >= 0.9 && parseFloat(newBeta) <= 1.1;
  const conc     = Math.max(0, 52 - weight);
  const res      = document.getElementById('sc-result');
  if (!res) return;
  res.innerHTML = `
    <div style="font-size:13px;font-weight:700;color:var(--text);margin-bottom:14px">Impact: Adding <span style="color:var(--teal)">${ticker}</span> at ${weight}%</div>
    <div class="i-row"><span class="i-label">Portfolio beta</span><span class="i-val">0.93 → ${newBeta} <span class="${bClass}">(${bSign}${bDelta})</span></span></div>
    <div class="i-row"><span class="i-label">Dividend yield</span><span class="i-val">3.8% → ${newYld}% <span class="pos">(+${yDelta}%)</span></span></div>
    <div class="i-row"><span class="i-label">Banking concentration</span><span class="i-val">52% → ${conc}%</span></div>
    <div class="i-row"><span class="i-label">W2 beta compliance</span><span class="i-val"><span class="badge ${w2ok ? 'b-teal' : 'b-red'}">${w2ok ? '✓ In range (0.9–1.1)' : '⚠ Out of range'}</span></span></div>
    <div class="i-row" style="border:none"><span class="i-label">Projected CAGR impact</span><span class="i-val pos">+0.4% estimated</span></div>
    <button class="btn btn-teal btn-full" style="margin-top:14px" onclick="alert('Scenario saved to tracker.\\nNo changes made to live portfolio.\\nReview in Scenario Log before confirming.')">Confirm &amp; save scenario</button>`;
};

/* ════════════════════════════════════════
   CHARTS
   ════════════════════════════════════════ */
function _destroyChart(key) {
  if (_chartMap[key]) { _chartMap[key].destroy(); delete _chartMap[key]; }
}

const CHART_DEFAULTS = {
  plugins: { legend: { display: false },
    tooltip: { backgroundColor:'#152540', titleColor:'#eef2ff', bodyColor:'#b0beda',
               borderColor:'rgba(255,255,255,0.08)', borderWidth:1, padding:12 }
  },
  scales: {
    y: { ticks:{ color:'#6a7d9e', font:{ size:10 } }, grid:{ color:'rgba(255,255,255,0.04)' }, border:{ display:false } },
    x: { ticks:{ color:'#6a7d9e', font:{ size:10 } }, grid:{ display:false }, border:{ display:false } }
  }
};

function drawPerfChart() {
  const ctx = document.getElementById('c-perf');
  if (!ctx || !window.Chart) return;
  _destroyChart('perf');
  _chartMap.perf = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Jan 26','Feb 26','Mar 26','Apr 26','May 26','Jun 26'],
      datasets: [
        { label:'Your W2 Portfolio', data:[0,6.2,14.8,28.3,39.1,47.6],
          borderColor:'#00d4a8', backgroundColor:'rgba(0,212,168,0.07)',
          fill:true, tension:0.4, pointRadius:4, pointBackgroundColor:'#00d4a8', pointBorderWidth:2, pointBorderColor:'#101d33' },
        { label:'KSE-100',           data:[0,5.8,12.1,24.5,35.2,43.6],
          borderColor:'#f0c040', tension:0.4, pointRadius:3, fill:false },
        { label:'Bank Deposit (11.5%)',data:[0,0.96,1.92,2.88,3.84,4.79],
          borderColor:'#6a7d9e', borderDash:[6,4], tension:0, pointRadius:0, fill:false },
      ]
    },
    options: { responsive:true, maintainAspectRatio:false,
      ...CHART_DEFAULTS,
      scales: { ...CHART_DEFAULTS.scales,
        y: { ...CHART_DEFAULTS.scales.y, ticks:{ ...CHART_DEFAULTS.scales.y.ticks, callback: v => v+'%' } }
      }
    }
  });
}

function drawBenchChart() {
  const ctx = document.getElementById('c-bench');
  if (!ctx || !window.Chart) return;
  _destroyChart('bench');
  _chartMap.bench = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Your W2','KSE-100','KSE-30','KMI-30','BKTI','OGTI','Deposits'],
      datasets: [{
        label: 'YTD Return %',
        data:  [47.6, 43.6, 41.2, 45.1, 52.1, 38.4, 11.5],
        backgroundColor: ['#00d4a8','#f0c040','#7fc95a','#4b9fff','#f0a040','#6a7d9e','#2a3d5a'],
        borderRadius: 7, borderSkipped: false
      }]
    },
    options: { responsive:true, maintainAspectRatio:false,
      ...CHART_DEFAULTS,
      scales: { ...CHART_DEFAULTS.scales,
        y: { ...CHART_DEFAULTS.scales.y, ticks:{ ...CHART_DEFAULTS.scales.y.ticks, callback: v => v+'%' } }
      }
    }
  });
}

function drawTaxChart() {
  const ctx = document.getElementById('c-tax');
  if (!ctx || !window.Chart) return;
  _destroyChart('tax');
  _chartMap.tax = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Net dividends kept','WHT deducted','CGT paid'],
      datasets: [{
        data: [761037, 134300, 6238],
        backgroundColor: ['#00d4a8','#f0c040','#ff5561'],
        borderColor: '#101d33', borderWidth: 4, hoverOffset: 8
      }]
    },
    options: { responsive:true, maintainAspectRatio:false, cutout:'72%',
      plugins: { legend:{ display:false },
        tooltip:{ backgroundColor:'#152540', titleColor:'#eef2ff', bodyColor:'#b0beda',
                  borderColor:'rgba(255,255,255,0.08)', borderWidth:1, padding:12,
                  callbacks:{ label: ctx => `${ctx.label}: ₨${ctx.raw.toLocaleString()}` } }
      }
    }
  });
}

/* ════════════════════════════════════════
   INIT
   ════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  initUser();
  renderHoldings();
  renderValuation();
  renderFunds();
  renderTransactions();
  setTimeout(drawPerfChart, 400);

  // Attach input listeners for preview
  ['tx-qty','tx-price','tx-brok'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', calcPreview);
  });
});
